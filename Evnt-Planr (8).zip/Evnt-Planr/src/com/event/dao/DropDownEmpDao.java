package com.event.dao;

import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.event.bean.Employee;
import com.event.web.jdbc.ConnectionClass;

public class DropDownEmpDao {
	public List<Employee> list() throws SQLException, FileNotFoundException {
		Connection con=null;
		Statement stmt= null;
		ResultSet rs=null;
		con=ConnectionClass.getConnection();

		List<Employee> empList = new ArrayList<>();
		try{
		  String s = "SELECT EMPLOYEE_ID FROM AMAL_EMPLOYEE ";
			stmt=con.createStatement();
			rs=stmt.executeQuery(s);
			while (rs.next()) {
				 
                String id = rs.getString("EMPLOYEE_ID");
                
                Employee emp = new Employee(id);
                   
               empList.add(emp);
           
            }   
		  } catch (SQLException ex) {
	            ex.printStackTrace();
	            throw ex;
	        }       
	         
	        return empList;
	    }
}
