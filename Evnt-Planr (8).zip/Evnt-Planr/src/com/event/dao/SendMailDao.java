package com.event.dao;

public class SendMailDao {

	
	
	
	
	
}
