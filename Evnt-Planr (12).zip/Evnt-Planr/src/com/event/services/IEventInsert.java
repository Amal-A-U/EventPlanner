package com.event.services;

import java.io.FileNotFoundException;
import java.sql.SQLException;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import com.event.bean.Event;

public interface IEventInsert {
	public String insertEvent(Event objEventBean) throws SQLException, AddressException, MessagingException, FileNotFoundException;

}
