package com.event.dao;

import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.event.bean.Employee;
import com.event.web.jdbc.ConnectionClass;

public class Emp_Registerdao {
	Connection con=null;
	Statement stmt= null;
	ResultSet rs=null;
	int r = 0;
	String s="fail";

	
	
	public String insertEmpDetails(Employee objEmp_RegBean) throws FileNotFoundException {
		try {
		con=ConnectionClass.getConnection();
		
			PreparedStatement ps =null;
			String eid=objEmp_RegBean.getEid();
			String fn=objEmp_RegBean.getFirstName();
			String ln=objEmp_RegBean.getLastName();
			String age=objEmp_RegBean.getAge();
			String gender=objEmp_RegBean.getGender();
			String did=objEmp_RegBean.getDept();
			String email=objEmp_RegBean.getEmail();
			String ph=objEmp_RegBean.getPhone();
			String pass=objEmp_RegBean.getPassword();
	
		String sql="insert into AMAL_EMPLOYEE (EMPLOYEE_ID,FNAME,LNAME,AGE,GENDER,DEPT_ID,EMAIL,PHONE,PASSWORD) values(?,?,?,?,?,?,?,?,?)";
		 ps=con.prepareStatement(sql);
		  ps.setString(1,eid);
		  ps.setString(2,fn);
		  ps.setString(3,ln);
		  ps.setString(4,age);
		  ps.setString(5,gender);
		  ps.setString(6,did);
		  ps.setString(7,email);
		  ps.setString(8,ph);
		  ps.setString(9,pass);
		 
		 r=ps.executeUpdate();
			if(r==1){
				s="success";
		
		}
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return s;


}
}
