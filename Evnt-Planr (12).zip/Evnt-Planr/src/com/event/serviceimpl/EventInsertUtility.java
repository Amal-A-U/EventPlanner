package com.event.serviceimpl;

import com.event.dao.AddEventDao;
import com.event.dao.RequestEventDao;
import com.event.services.IEventInsert;

public class EventInsertUtility {
	public static IEventInsert getInsertionUtility(String type){
		if(type=="AddEvent"){
			return new AddEventDao();
		}
		else
			return new RequestEventDao();
		
	}

}
