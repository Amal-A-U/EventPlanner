package com.event.servlet;

import java.io.IOException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.event.bean.Department;
import com.event.dao.DropDownDeptDao;

/**
 * Servlet implementation class MainDeptServlet
 */
@WebServlet("/MainDeptServlet")
public class MainDeptServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setHeader("Cache-Control","no-cache"); 
		response.setHeader("Cache-Control","no-store"); 
		response.setDateHeader("Expires", 0); 
		response.setHeader("Pragma","no-cache");
		
	
		try
		{
			DropDownDeptDao objDropDownDeptDao=new DropDownDeptDao();
			List<Department> dlist = objDropDownDeptDao.list();
			request.setAttribute("department", dlist);
			   System.out.println(dlist.get(0).getDept_id()) ;
			RequestDispatcher dispatcher = request.getRequestDispatcher("/Main.jsp");
			dispatcher.forward(request, response);
	}
		catch(Exception e){
			e.printStackTrace();
		}

}

}
