package com.event.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.event.bean.Event;
import com.event.dao.ViewEventDao;

/**
 * Servlet implementation class EventList
 */
@WebServlet("/EventList")
public class EventList extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		if(action==null){
			emphome(request,response);
		}
		
		else {
			System.out.println("action1");
			
		
			listEvents(request,response);
			
		}
		
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);
	}
 
	private void listEvents(HttpServletRequest request, HttpServletResponse response) 
			  throws Exception{
				// get event-details from dao
				ViewEventDao objViewEventDao = new ViewEventDao();
				List<Event> list_events=objViewEventDao.EventRequest();
		/*	for(AddEventBean list :list_events){
					
					System.out.println("value"+ list.getEvent_name());
				}*/
				// add event-details to the request
				request.setAttribute("AMAL_EVENT",list_events);
				
				// send to jsp page(view)
				RequestDispatcher dispatcher = request.getRequestDispatcher("/admin-home.jsp");
				dispatcher.forward(request, response);
				
			}
			
}
