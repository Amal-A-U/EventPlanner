package com.event.dao;

import java.sql.*;
import com.event.bean.Event;
import com.event.web.jdbc.ConnectionClass;
public class AddEventDao {
	private String s=null;
	Connection con=null;
	Statement stmt= null;
	ResultSet rs1 = null;
	
	int rs = 0;
public String insertEvent(Event objAddEventBean) throws SQLException {
	try {
	String eventname=objAddEventBean.getEvent_name();
	String startdate=objAddEventBean.getStart_date();
	String enddate=objAddEventBean.getEnd_date();
	String venue=objAddEventBean.getVenue();
	String eventtime=objAddEventBean.getEvent_time();
	Float expectamount=objAddEventBean.getExpected_amount();
	String admin_id=objAddEventBean.getAdmin_id();
	String coordinator_id=objAddEventBean.getCoordinator_id();
	
	con=ConnectionClass.getConnection();
	
	stmt=con.createStatement();

PreparedStatement ps=null;
PreparedStatement ps1=null;

	String status="approved";
	System.out.println("1");

	  String sql1="select count(employee_id) from amal_employee where dept_id in(select dept_id from amal_employee where employee_id=?) ";
		System.out.println("2");
		
		ps1=con.prepareStatement(sql1);
		 ps1.setString(1,admin_id);
	rs1=ps1.executeQuery();
	System.out.println("3");

	float emp_count = 0;
	while(rs1.next()){
		// retrieve data from result set row
		emp_count=rs1.getInt(1);
	}
	System.out.println(emp_count);
	Float emp_expect=(float) expectamount/emp_count;
	System.out.println("5");
		System.out.println(emp_expect);
		String sql="insert into AMAL_EVENT (EVENT_NAME,START_DATE,END_DATE,VENUE,EVENT_TIME,EXPECTED_AMOUNT,EVENT_STATUS,ADMIN_ID,COORDINATOR_ID,EMP_EXPECT_AMT) values(?,?,?,?,?,?,?,?,?,?)";
		 ps=con.prepareStatement(sql);
	     ps.setString(1,eventname);
	     ps.setString(2,startdate);
	     ps.setString(3,enddate);
	     ps.setString(4,venue);
	     ps.setString(5,eventtime);
	     ps.setFloat(6,expectamount);
	     ps.setString(7,status);
	     ps.setString(8,admin_id);
	     ps.setString(9,coordinator_id);
	     ps.setFloat(10,emp_expect);
	     rs=ps.executeUpdate();
		
		System.out.println("afterdao");
		if(rs==1)
			s="success";
		else
			s="fail";
		
}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	return s;
	}

}
