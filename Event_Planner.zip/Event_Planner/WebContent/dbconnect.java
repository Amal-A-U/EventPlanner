
package com.event.util;
import java.sql.* ;  // for standard JDBC programs

public class dbconnect {

	public static void main(String[] args) {
		 //Creating the connection
        String url = "jdbc:oracle:thin:@sla18326:1521:ukahp1d";
        String user = "AZT_TRN";
        String pass = "Azt_trn1#";
        Connection conn=null;
        Statement st=null;

        try
        {
            DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
 
            //Reference to connection interface
            conn = DriverManager.getConnection(url,user,pass);
             st = conn.createStatement();
             String sql="select * from AMAL_EMPLOYEE";
            ResultSet rs= st.executeQuery(sql);
         
            	while(rs.next()){  
            	System.out.println(rs.getString(1));  
            	}  

      
            conn.close();
        }
        catch(Exception ex)
        {
            System.err.println(ex);
        }


	}

}
