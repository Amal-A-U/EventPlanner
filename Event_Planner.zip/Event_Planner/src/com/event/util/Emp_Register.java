package com.event.util;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Emp_Register
 */
@WebServlet("/Emp_Register")
public class Emp_Register extends HttpServlet {
	private static final long serialVersionUID = 1L;
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//set the content type
		response.setContentType("text/html");
		//get the printwriter
		PrintWriter out=response.getWriter();
		//generate html content
		out.println("Details\n");
		out.println(request.getParameter("firstName")+request.getParameter("lastName"));
		out.println(request.getParameter("eid"));
		out.println(request.getParameter("gender"));
		out.println(request.getParameter("age"));
		out.println(request.getParameter("email"));
		out.println(request.getParameter("phone"));
		out.println(request.getParameter("dept"));
		out.println(request.getParameter("pass"));
		out.println(request.getParameter("pass1"));
	
	}


}
