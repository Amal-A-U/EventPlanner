package com.DAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import com.ConnectionString.*;

import com.Bean.*;

public class AppointmentListDAO {
	public List<Appointmentbean> getAppointment(int did) throws SQLException  
	{
		List<Appointmentbean> al1=new <Appointmentbean>ArrayList();

		 Connection con=null;
		PreparedStatement preparedStatement;
		
		try {
			
		   // int d_id=Integer.parseInt(did);
			
		    con = ConnectionString.getConnection();	
			
			String query = "SELECT A_ID,P_ID,A_DATE,A_TIME,P_STATUS FROM PG_APPOINTMENT WHERE D_ID=?";
			 
			 preparedStatement = con.prepareStatement(query);
			 preparedStatement.setInt(1, did);
			 ResultSet myRs=preparedStatement.executeQuery();
		
			 while (myRs.next()) {

				
				 int a_id = myRs.getInt("A_ID");
				 int p_id = myRs.getInt("P_ID");
				 String a_date = myRs.getString("A_DATE");
				 int a_time = myRs.getInt("A_TIME");
				 String p_status = myRs.getString("P_STATUS");
				 
				 
				 Appointmentbean abean = new  Appointmentbean(a_date,a_time,p_id,p_status,a_id);

				 
				 al1.add(abean);				
			                        }


			
			 myRs.close(); 
			 preparedStatement.close();
		}
		
		  catch(SQLException e)
		  {
		 e.printStackTrace();
			 
		  }
		finally
		{
			
			con.close();
		}
		return al1;
		
	 }

}
