package com.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.Bean.*;
import com.ConnectionString.*;
public class PatientregDAO {
	public String patientRegister(PatientRegBean objbean)
	{
		 String firstName = objbean.getName();
		 String address = objbean.getAddress();
		 String gender = objbean.getGender();
		 String email = objbean.getMail();
		 String phoneNumber =objbean.getPhone();
		 String username=objbean.getUsername();
		 String password=objbean.getPassword();
		 Connection con = null;
		 PreparedStatement preparedStatement = null;
		 try
		 {
		 con = ConnectionString.getConnection();
		 String query = "insert into PG_PATIENT_REG(P_NAME,P_GENDER,P_PHONE,P_EMAIL,P_ADDRESS,P_TYPE) values (?,?,?,?,?,0)"; //Insert user details into the table 'USERS'
		 preparedStatement = con.prepareStatement(query); //Making use of prepared statements here to insert bunch of data
		 preparedStatement.setString(1, firstName);
		 preparedStatement.setString(2, gender);
		 preparedStatement.setString(3, phoneNumber);
		 preparedStatement.setString(4, email);
		 preparedStatement.setString(5, address);
		 preparedStatement.executeUpdate();
		 String regquery="select max(P_ID) as max from PG_PATIENT_REG";
		 preparedStatement = con.prepareStatement(regquery);
		 ResultSet rs=preparedStatement.executeQuery();
			int max=0;
			while(rs.next())
			{
				 max=rs.getInt("max");
			}
			String logquery="insert into PG_LOGIN(USERNAME,PASSWORD,P_ID,L_TYPE) values(?,?,?,0)";
			preparedStatement = con.prepareStatement(logquery); //Making use of prepared statements here to insert bunch of data
			preparedStatement.setString(1, username);
			preparedStatement.setString(2, password);
			preparedStatement.setInt(3, max);
			 int i=preparedStatement.executeUpdate();
		 if (i!=0)  //Just to ensure data has been inserted into the database
		return "SUCCESS";
		 }
		 catch(SQLException e)
		 {
		 e.printStackTrace();
			 //System.out.println("an error in program has occured");
		 }
		 
		 return "something went wrong";  // On failure, send a message from here.

		
	}

}
