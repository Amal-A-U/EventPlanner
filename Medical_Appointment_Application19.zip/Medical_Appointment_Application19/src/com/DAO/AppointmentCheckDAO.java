package com.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.Bean.Appointmentbean;
import com.ConnectionString.ConnectionString;

public class AppointmentCheckDAO {
	//
	public List<Appointmentbean> checkAppointment(int did,String date) throws SQLException  
	{
		List<Appointmentbean> al2=new <Appointmentbean>ArrayList();
		String booked="";
		 Connection con=null;
		PreparedStatement preparedStatement;
		
		try {
			
		   // int d_id=Integer.parseInt(did);
			System.out.println(date);
		    con = ConnectionString.getConnection();	
			
			String query = "SELECT A_BOOKED, A_TIME FROM PG_APPOINTMENT WHERE D_ID=? AND A_DATE=? ";
			 
			 preparedStatement = con.prepareStatement(query);
			 preparedStatement.setInt(1, did);
			 preparedStatement.setString(2,date);
			
			 ResultSet myRs=preparedStatement.executeQuery();
		
			 while (myRs.next()) {

				
				 int a_booked = myRs.getInt("A_BOOKED");
				 int time=myRs.getInt("A_TIME");
				 
				 if(a_booked==1)
				 {
					 booked="booked";
				 }
				 Appointmentbean abean = new  Appointmentbean(time,booked);

				 
				 al2.add(abean);				
			                        }


			
			 myRs.close(); 
			 preparedStatement.close();
		}
		
		  catch(SQLException e)
		  {
		 e.printStackTrace();
			 
		  }
		finally
		{
			
			con.close();
		}
		return al2;
		
	 }

}
