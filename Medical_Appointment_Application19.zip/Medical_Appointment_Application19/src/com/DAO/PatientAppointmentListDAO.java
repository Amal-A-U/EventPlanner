package com.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.Bean.Appointmentbean;
import com.ConnectionString.ConnectionString;

public class PatientAppointmentListDAO {
	public List<Appointmentbean> getAppointment(int pid) throws SQLException  
	{
		List<Appointmentbean> al2=new <Appointmentbean>ArrayList();

		 Connection con=null;
		PreparedStatement preparedStatement;
		
		try {
			
		   // int d_id=Integer.parseInt(did);
			
		    con = ConnectionString.getConnection();	
			
			String query = "SELECT A_ID,D_ID,A_DATE,A_TIME FROM PG_APPOINTMENT WHERE P_ID=?";
			 
			 preparedStatement = con.prepareStatement(query);
			 preparedStatement.setInt(1, pid);
			 ResultSet myRs=preparedStatement.executeQuery();
		
			 while (myRs.next()) {

				
				 int a_id = myRs.getInt("A_ID");
				 int d_id = myRs.getInt("D_ID");
				 String a_date = myRs.getString("A_DATE");
				 int a_time = myRs.getInt("A_TIME");
				
				 
				 
				 Appointmentbean abean = new  Appointmentbean(d_id,a_date,a_time,a_id);

				 
				 al2.add(abean);				
			                        }


			
			 myRs.close(); 
			 preparedStatement.close();
		}
		
		  catch(SQLException e)
		  {
		 e.printStackTrace();
			 
		  }
		finally
		{
			
			con.close();
		}
		return al2;
		
	 }

	
	
}
