package com.DAO;
import java.sql.Connection;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.Bean.*;
import com.ConnectionString.*;


public class LoginDAO {
	public List<PatientRegBean> validateUser(LoginBean objbean)  {
		PatientRegBean objPatientRegBean=new PatientRegBean();
		// TODO Auto-generated method stub
		String userName = objbean.getUsername(); //Keeping user entered values in temporary variables.
		String password = objbean.getPassword();
		List<PatientRegBean> list=new ArrayList<PatientRegBean>();
		Connection con = null;
		Statement statement = null;
		ResultSet resultSet = null;
		
		
		 int i=0;
		String userNameDB = "";
		String passwordDB = "";
		int typeDB=0;
		int pDB;
		
		try
		{
			objPatientRegBean.setUsertype("inavalid");
			con = ConnectionString.getConnection();
			statement = con.createStatement();
			
			resultSet = statement.executeQuery("select username,password,L_TYPE,p_id,d_id from PG_LOGIN where username='"+userName+"' and  password='"+password+"'");
			
			while(resultSet.next()) 
			{
				i=i+1;
				System.out.println(resultSet.getString("username"));
				System.out.println(resultSet.getString("password"));
				System.out.println(resultSet.getInt("p_id"));
			
				userNameDB = resultSet.getString("username"); //fetch the values present in database
				passwordDB = resultSet.getString("password");
				typeDB=resultSet.getInt("L_TYPE");
			  
			    objPatientRegBean.setD_id(resultSet.getInt("d_id"));
				System.out.println(resultSet.getInt("p_id"));
				objPatientRegBean.setId(resultSet.getInt("p_id"));
				
				list.add(objPatientRegBean);
				if(userName.equals(userNameDB) && password.equals(passwordDB))
				{
					if(typeDB==0)
					   {
						
						objPatientRegBean.setUsertype("PATIENT");
						   break;
					   }
					   else if(typeDB==1)
					   {
						   objPatientRegBean.setUsertype("DOCTOR");
						   break;
					   }
					   else if(typeDB==2)
					   {
						   objPatientRegBean.setUsertype("ADMIN");
						   break;
					   }
					   
					
				}
				
			}
				
			list.add(objPatientRegBean);			

		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		
		return list; // Just returning appropriate message otherwise

	}
}
