package com.DAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.Bean.*;
import com.Bean.Doctor;
import com.ConnectionString.ConnectionString;

public class AppointmentDAO {
	
	public String doctorAppointment(Appointmentbean appbean)
	{
	
	 int p_id=appbean.getP_id();
	
	 int d_id=appbean.getD_id();
	 String date=appbean.getDate();
	 int time = appbean.getTime();
	 int i=0;
	 Connection con = null;
	 PreparedStatement preparedStatement = null;
	 try
	 {
	 con = ConnectionString.getConnection();
	 String query1="select A_BOOKED  from PG_APPOINTMENT where A_DATE='"+date+"' AND A_TIME='"+time+"' AND D_ID='"+d_id+"'";
	 preparedStatement = con.prepareStatement(query1);

	 ResultSet rs=preparedStatement.executeQuery();
	 int book=0;
	 while(rs.next()){
	 book=rs.getInt("A_BOOKED");
	 }
	 if(book!=1)
	 {
	 String query2 = "insert into PG_APPOINTMENT(D_ID,P_ID,A_DATE,A_TIME,P_STATUS,A_BOOKED) values (?,?,?,?,'confirmed',1)"; //Insert user details into the table 'USERS'
	 preparedStatement = con.prepareStatement(query2); //Making use of prepared statements here to insert bunch of data
	 preparedStatement.setInt(1, d_id);
	 preparedStatement.setInt(2, p_id);
	 preparedStatement.setString(3, date);
	 preparedStatement.setInt(4, time);
	 i=preparedStatement.executeUpdate();
	 }
	 System.out.println("the value of i is"+i);
	 if(i!=0)
	 {
		 return "SUCCESS";
	 }
	 }
	 catch(Exception e)
	 {
		 e.printStackTrace();
	 }
	 return "BOOKING NOT POSIBLE";
	}
	
}
