package com.Bean;

public class LoginBean {
	private String username;
	private String password;
	private int p_id;
	
	
	
	public int getP_id() {
		System.out.println("the id on bean is "+p_id);
		return p_id;
	}
	public void setP_id(int p_id) {
		this.p_id = p_id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
}
