package com.Servlet;
import com.DAO.*;
import com.Bean.*;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class PatientRegistrationServlet
 */
@WebServlet("/PatientRegistrationServlet")
public class PatientRegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PatientRegistrationServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PatientRegBean objbean=new PatientRegBean();
		PrintWriter out = response.getWriter();
		String firstName = request.getParameter("name");
		 String address = request.getParameter("address");
		 String gender = request.getParameter("gender");
		 String email = request.getParameter("mail");
		 String phoneNumber = request.getParameter("phone");
		 String userName = request.getParameter("username");
		 String password = request.getParameter("password");
		 
		 
		 objbean.setName(firstName);
		 objbean.setAddress(address);
		 objbean.setMail(email);
		 objbean.setGender(gender);
		 objbean.setPhone(phoneNumber);
		 objbean.setUsername(userName);
		 objbean.setPassword(password); 
		 
		  PatientregDAO objdao=new PatientregDAO();
          String userRegistered = objdao.patientRegister(objbean);
		 
		 if(userRegistered.equals("SUCCESS"))   //On success, you can display a message to user on Home page
		 {
			 request.getRequestDispatcher("/patient_registration.jsp").include(request, response);
			 out.print("<html><body>");  
	         out.println("<script type=\"text/javascript\">");
	         out.println("alert('registered successfully');");
	         out.println("</script>");
	         out.print("</body></html>");
	         out.close(); 
		 }
		 else   //On Failure, display a meaningful message to the User.
		 {

			 request.getRequestDispatcher("/patient_registration.jsp").include(request, response);
			 out.print("<html><body>");  
	         out.println("<script type=\"text/javascript\">");
	         out.println("alert('registered successfully');");
	         out.println("</script>");
	         out.print("</body></html>");
	         out.close(); 
		 }
	}

}
