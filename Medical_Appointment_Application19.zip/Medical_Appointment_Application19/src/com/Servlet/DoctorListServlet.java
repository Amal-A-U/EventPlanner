package com.Servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.Bean.*;
import com.DAO.*;

/**
 * Servlet implementation class DoctorListServlet
 */
@WebServlet("/DoctorListServlet")
public class DoctorListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DoctorListServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
			
		try {
			HttpSession session = request.getSession();
			response.setHeader("Cache-Control","no-cache"); 
            response.setHeader("Cache-Control","no-store"); 
            response.setDateHeader("Expires", 0); 
            response.setHeader("Pragma","no-cache");
            String username=(String)session.getAttribute("ADMIN");
        if (null == username) {
                      request.setAttribute("Error", "Session has ended.  Please login.");
                       request.getRequestDispatcher("/login_page.jsp").forward(request, response);
                            }
			
			String action = request.getParameter("action");
			
			if(action==null)
			{
				listDoctor(request, response);
			}
			else if(action.equals("delete") && action!=null)
			{
			deleteDoctor(request,response);	
			}
		
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}


	
	
	private void listDoctor(HttpServletRequest request, HttpServletResponse response) 
			throws Exception {
			DoctorList dl=new DoctorList();
			
			List<Doctor> doctor = dl.getDoctor();
			
			
			
			 request.setAttribute("DOCTOR_LIST", doctor);
			
			 request.getRequestDispatcher("/Admin_control_panel.jsp").forward(request, response);
		}
	
	private void deleteDoctor(HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		      DoctorList dl=new DoctorList();

			
			String theDoctorID = request.getParameter("d_id");
		
			
			
			   dl.deleteDoctor(theDoctorID);
			
			
			listDoctor(request, response);
		}



}
