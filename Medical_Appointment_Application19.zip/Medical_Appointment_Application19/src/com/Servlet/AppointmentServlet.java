package com.Servlet;
import java.io.*;

import java.text.SimpleDateFormat;

import java.util.Date;
import com.Bean.*;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.DAO.*;
/**
 * Servlet implementation class AppointmentServlet
 */
@WebServlet("/AppointmentServlet")
public class AppointmentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AppointmentServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Appointmentbean appbean=new Appointmentbean();
		
		LoginBean pbean=new LoginBean();
		PrintWriter out = response.getWriter();
		
		String pid=request.getParameter("p_id");
		System.out.println("the value of pid is"+pid);
		int p_id=Integer.parseInt(pid);
		System.out.println("the p_id is"+pid);
		String did=request.getParameter("doctor");
		int d_id=Integer.parseInt(did);
		String dt=request.getParameter("date");
		String time=request.getParameter("time");
		int time1=Integer.parseInt(time);

		appbean.setD_id(d_id);
		appbean.setP_id(p_id);
		appbean.setDate(dt);
		appbean.setTime(time1);
		
		
		 AppointmentDAO appdao=new AppointmentDAO();
		 String appointment = appdao.doctorAppointment(appbean);
		 
		 if(appointment.equals("SUCCESS"))   //On success, you can display a message to user on Home page
		 {
			 request.getRequestDispatcher("/Appointment_page.jsp").include(request, response);
			 out.print("<html><body>");  
	         out.println("<script type=\"text/javascript\">");
	         out.println("alert('success');");
	         out.println("</script>");
	         out.print("</body></html>");
	         out.close(); 
		 }
		 else   //On Failure, display a meaningful message to the User.
		 {

			 request.getRequestDispatcher("/Appointment_page.jsp").include(request, response);
			 out.print("<html><body>");  
	         out.println("<script type=\"text/javascript\">");
	         out.println("alert('already booked');");
	         out.println("</script>");
	         out.print("</body></html>");
	         out.close(); 
		 }
		
		
	}

}
