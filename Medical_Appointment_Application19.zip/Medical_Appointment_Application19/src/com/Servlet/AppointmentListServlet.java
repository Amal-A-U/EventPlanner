package com.Servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.Bean.*;
import com.DAO.*;

/**
 * Servlet implementation class AppointmentListServlet
 */
@WebServlet("/AppointmentListServlet")
public class AppointmentListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AppointmentListServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
			 HttpSession session = request.getSession();
			response.setHeader("Cache-Control","no-cache"); 
            response.setHeader("Cache-Control","no-store"); 
            response.setDateHeader("Expires", 0); 
            response.setHeader("Pragma","no-cache");
            String username=(String)session.getAttribute("DOCTOR");
        if (null == username) {
                      request.setAttribute("Error", "Session has ended.  Please login.");
                       request.getRequestDispatcher("/login_page.jsp").forward(request, response);
                               }
	 
			listAppointment(request,response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	private void listAppointment(HttpServletRequest request, HttpServletResponse response) 
			throws Exception {
		HttpSession session = request.getSession();

		int   did=(int)session.getAttribute("d_id");
		 System.out.println("the d_id on appointment list servlet is:"+did);
			AppointmentListDAO al=new AppointmentListDAO();
			
			List<Appointmentbean> app = al.getAppointment(did);
			
			
			
			 request.setAttribute("APPOINTMENT_LIST", app);
			
			 request.getRequestDispatcher("/Doctor_control_panel.jsp").forward(request, response);
		}

}
