package com.Servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.Bean.*;
import com.DAO.*;

/**
 * Servlet implementation class AppointmentCheckServlet
 */
@WebServlet("/AppointmentCheckServlet")
public class AppointmentCheckServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AppointmentCheckServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
			 
			checkAppointment(request,response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	private void checkAppointment(HttpServletRequest request, HttpServletResponse response) 
			throws Exception {
		   
		   
		   
	
		     String did=request.getParameter("doctor");
		     System.out.println("the did in check servlet is"+did);
		     int d_id=Integer.parseInt(did);
		
		     String date = request.getParameter("date");
		     System.out.println("the date is"+date);
		

			 AppointmentCheckDAO acl=new AppointmentCheckDAO();
			
			List<Appointmentbean> app = acl.checkAppointment(d_id,date);
			
			
			
			 request.setAttribute("APPOINTMENT_LIST2", app);
			
			 request.getRequestDispatcher("/Appointment_page.jsp").forward(request, response);
		
		}


}
