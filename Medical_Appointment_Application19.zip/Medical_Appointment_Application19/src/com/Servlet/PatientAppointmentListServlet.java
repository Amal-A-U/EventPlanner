package com.Servlet;
import com.Bean.*;
import com.DAO.*;
import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.Bean.Appointmentbean;
import com.DAO.AppointmentListDAO;

/**
 * Servlet implementation class PatientAppointmentListServlet
 */
@WebServlet("/PatientAppointmentListServlet")
public class PatientAppointmentListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PatientAppointmentListServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		// TODO Auto-generated method stub
		
		try {
			HttpSession session = request.getSession();
			response.setHeader("Cache-Control","no-cache"); 
            response.setHeader("Cache-Control","no-store"); 
            response.setDateHeader("Expires", 0); 
            response.setHeader("Pragma","no-cache");
            String username=(String)session.getAttribute("PATIENT");
        if (null == username) {
                      request.setAttribute("Error", "Session has ended.  Please login.");
                       request.getRequestDispatcher("/login_page.jsp").forward(request, response);
                               }

			listPatientAppointment(request,response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	private void listPatientAppointment(HttpServletRequest request, HttpServletResponse response) 
			throws Exception {
		  HttpSession session = request.getSession();
		int   pid=(int)session.getAttribute("id");
		System.out.println("the value of pid is:"+pid);
		
			PatientAppointmentListDAO pal=new PatientAppointmentListDAO();
			
			List<Appointmentbean> app = pal.getAppointment(pid);
			
			request.setAttribute("APPOINTMENT_LIST", app);
			
			request.getRequestDispatcher("/PatientAppointmentView.jsp").forward(request, response);
		}


}
