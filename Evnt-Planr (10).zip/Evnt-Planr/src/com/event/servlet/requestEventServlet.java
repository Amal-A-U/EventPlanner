package com.event.servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.event.bean.Event;

import com.event.dao.RequestEventDao;

@WebServlet("/requestEventServlet")
public class requestEventServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setHeader("Cache-Control","no-cache"); 
		response.setHeader("Cache-Control","no-store"); 
		response.setDateHeader("Expires", 0); 
		response.setHeader("Pragma","no-cache");
		HttpSession session=request.getSession(false);
		String coordinator_id;
		coordinator_id=(String) session.getAttribute("uid");
		System.out.println(coordinator_id);
		Event objAddEventBean = new Event();
		objAddEventBean.setEvent_name(request.getParameter("eventname"));
		objAddEventBean.setStart_date(request.getParameter("startdate"));
		objAddEventBean.setEnd_date(request.getParameter("enddate"));
		objAddEventBean.setVenue(request.getParameter("venue"));
		objAddEventBean.setEvent_time(request.getParameter("time"));
		
		String str=request.getParameter("expectamount");
		System.out.println("serv "+str);
		Float f=(float) Integer.parseInt(str);
	
		objAddEventBean.setExpected_amount(f);
		System.out.println(f);
		
		objAddEventBean.setCoordinator_id(coordinator_id);
		
	
		
		RequestEventDao objRequestEventDao = new RequestEventDao();
		
	    String s=null;
		try {
			s = objRequestEventDao.insertEvent(objAddEventBean);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    if(s.equals("success")){
	    	request.setAttribute("eventrequest", "Event Requested Successfully");
						RequestDispatcher dispatcher = request.getRequestDispatcher("/requestEvent.jsp");
						dispatcher.forward(request, response);
		}
	    else if(s.equals("fail")){
	    	String[] msg1 = {"Something got wrong...  please try again !"};
			request.setAttribute("msg1", msg1);
	    	RequestDispatcher dispatcher = request.getRequestDispatcher("/requestEvent.jsp");
					dispatcher.forward(request, response);
	    }
		
		
		
	}

	
	
	
	
	
	
	}


