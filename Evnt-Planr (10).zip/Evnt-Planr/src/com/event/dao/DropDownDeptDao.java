package com.event.dao;

import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.event.bean.Department;
import com.event.web.jdbc.ConnectionClass;

public class DropDownDeptDao {
	public List<Department> list() throws SQLException, FileNotFoundException {
		Connection con=null;
		Statement stmt= null;
		ResultSet rs=null;
		con=ConnectionClass.getConnection();

		List<Department> deptList = new ArrayList<>();
		try{
		  String s = "SELECT * FROM AMAL_DEPARTMENT ";
			stmt=con.createStatement();
			rs=stmt.executeQuery(s);
			while (rs.next()) {
				 String id = rs.getString("dept_id");
                String name = rs.getString("dept_name");
                Department dept = new Department(id, name);
                   
                deptList.add(dept);
           
            }   
		  } catch (SQLException ex) {
	            ex.printStackTrace();
	            throw ex;
	        }       
	         
	        return deptList;
	    }
}
