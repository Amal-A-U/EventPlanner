package com.event.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class SendMail {
	public void sendEmail(String eventname, List<String> tolist, String from, String body)  throws AddressException,
    MessagingException{
		  List<String> list1=new ArrayList<String>();
		  list1=tolist;
                        
                        // Recipient's email ID needs to be mentioned.
             // String to = "extern_jose.bismi@allianz.com";

              // Sender's email ID needs to be mentioned
            //  String from = "extern_jose.bismi@allianz.com";

              // Assuming you are sending email from localhost
              String host = "tmu-econ.mail.allianz";

              // Get system properties
              Properties properties = System.getProperties();

              // Setup mail server
              properties.setProperty("mail.smtp.host", host);

              // Get the default Session object.
              Session session = Session.getDefaultInstance(properties);

              try {

                 // Create a default MimeMessage object.
                 MimeMessage message = new MimeMessage(session);

                 // Set From: header field of the header.
                 message.setFrom(new InternetAddress(from));
                 InternetAddress[] address = new InternetAddress[list1.size()];
                 
                 
                 for (int i=0;i<list1.size();i++) {
          // String temp=list1.get(i);
                 // Set To: header field of the header.
           
           address[i] = new InternetAddress(list1.get(i));
                 }

              //   message.addRecipient(Message.RecipientType.TO, new InternetAddress(address));
                 message.setRecipients(Message.RecipientType.TO, address);
                 // Set Subject: header field
                 message.setSubject(eventname);

                 // Now set the actual message
                 //message.setText("This is actual message");#
                 message.setText(body);

                 // Send message
                 Transport.send(message);
                
                 System.out.println("Sent message successfully....");
               
                 
              } catch (MessagingException mex) {
                 mex.printStackTrace();
              }

                        
        }
}
