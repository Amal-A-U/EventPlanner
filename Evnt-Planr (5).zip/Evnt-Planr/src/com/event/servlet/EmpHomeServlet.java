package com.event.servlet;

import java.io.IOException;

import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.event.bean.Employee;
import com.event.bean.Event;
import com.event.dao.EmpHomeDao;


/**
 * Servlet implementation class EmpHomeServlet
 */
@WebServlet("/EmpHomeServlet")
public class EmpHomeServlet extends HttpServlet {
	EmpHomeDao objEmpHomeDao=new EmpHomeDao();
	private static final long serialVersionUID = 1L;
       
 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		response.setHeader("Cache-Control","no-cache"); 
		response.setHeader("Cache-Control","no-store"); 
		response.setDateHeader("Expires", 0); 
		response.setHeader("Pragma","no-cache");
	
			String action=request.getParameter("action");
			HttpSession session1=request.getSession(false);
			String contribute=(String) session1.getAttribute("al");
			
			
		
			System.out.println("action1"+action);
		if(action==null){
			System.out.println("null");
			emphome(request,response);
		}
		
		else if (action.equals("accept")){
			System.out.println("acce");
			useraccept(request,response);
			
		}
		else if (action.equals("reject")){
			System.out.println("rejj");
			
		
			reject(request,response);
			
		}
		
	
	}
	public void emphome(HttpServletRequest request, HttpServletResponse response){
		try{
			Employee objEmp = new Employee();
				HttpSession session=request.getSession(false);
				String employee_id;
				employee_id=(String) session.getAttribute("uid");
				objEmp.setEid(employee_id);
						// get event-details from dao
				EmpHomeDao objEmpHomeDao = new EmpHomeDao();
						List<Event> list_events=objEmpHomeDao.GetEvents(objEmp);
				/*	for(AddEventBean list :list_events){
							
							System.out.println("value"+ list.getEvent_name());
						}*/
						// add event-details to the request
						request.setAttribute("AMAL_EVENT",list_events);
						
						// send to jsp page(view)
						RequestDispatcher dispatcher = request.getRequestDispatcher("/employee-home.jsp");
						dispatcher.forward(request, response);
						
				
		}
		catch(Exception exc){
			exc.printStackTrace();
		}
	}
	
	public void useraccept(HttpServletRequest request, HttpServletResponse response) throws IOException{
		HttpSession session=request.getSession(false);
		System.out.println("action2");
	
		
		String employee_id;
		employee_id=(String) session.getAttribute("uid");
		/*String contribute=(String) session.getAttribute("al");
		System.out.println(contribute);*/
//		System.out.println(request.getParameter("contribute"));
		String event_id=request.getParameter("event_id");
		String contribution=request.getParameter("contribution");
	    String total=request.getParameter("total_amount");
	 float total_amount=Float.parseFloat(total);
	 float contribute=Float.parseFloat(contribution);
		System.out.println(contribute);
		EmpHomeDao objEmpHomeDao= new EmpHomeDao();
		
	/*	Float contribute=(float) 120;*/
		String s=objEmpHomeDao.accept(contribute,event_id,employee_id,total_amount);
		if(s.equals("success"))
		{
	          emphome(request,response);
		}
		
		else
		{
	          emphome(request,response);
		}
	
		
	}
public void reject(HttpServletRequest request, HttpServletResponse response) throws IOException{
	HttpSession session=request.getSession(false);

	String employee_id=(String) session.getAttribute("uid");
	String event_id=request.getParameter("event_id");
	EmpHomeDao objEmpHomeDao= new EmpHomeDao();
	String s=objEmpHomeDao.reject(event_id,employee_id);
	if(s.equals("success"))
	{
          emphome(request,response);
          
	}
	
	else
	{
          emphome(request,response);
	}
		
		
	}
	
}





	