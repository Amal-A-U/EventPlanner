package com.event.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.event.bean.Event;
import com.event.bean.Event_Details;
import com.event.dao.ViewEventDao;

/**
 * Servlet implementation class ViewEvent
 */
@WebServlet("/ViewEvent")
public class ViewEvent extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setHeader("Cache-Control","no-cache"); 
		response.setHeader("Cache-Control","no-store"); 
		response.setDateHeader("Expires", 0); 
		response.setHeader("Pragma","no-cache");
		//list the students in mvc fashion
		try{
			String action=request.getParameter("action");
			if(action==null){
				action="load";
				System.out.println(" Action = null");
			}
			
			switch(action){
			case "load":
				listEvents(request,response);
				break;
			case "edit":
				edit(request,response);
				break;
			case "delete":
				delete(request,response);
				break;
			case "update":
				updateEvent(request,response);
				break;
			case "contributes":
				contributeEvent(request,response);
				break;
			case "search":
				searchEvents(request,response);
				break;
			case "contributeHistory":
				contributeHistory(request,response);
				break;
				
				
				
			default:
				listEvents(request,response);
			}
		
		}
		catch(Exception exc){
			throw new ServletException(exc);
		}
		

	}
	private void contributeHistory(HttpServletRequest request, HttpServletResponse response) throws SQLException, ServletException, IOException {
		HttpSession session=request.getSession(false);
		 String admin_id= (String) session.getAttribute("uid");
				// get event-details from dao
				ViewEventDao objViewEventDao = new ViewEventDao();
		List<Event_Details> list_event_details=objViewEventDao.EventInner(admin_id);
		request.setAttribute("EVENT_DETAILS",list_event_details);
		// send to jsp page(view)
		RequestDispatcher dispatcher = request.getRequestDispatcher("/employee-event-inner.jsp");
		dispatcher.forward(request, response);
		
		
	}
	private void searchEvents(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, SQLException {
		String content=request.getParameter("content");
	System.out.println(content);
		HttpSession session=request.getSession(false);
		 String admin_id= (String) session.getAttribute("uid");
				// get event-details from dao
				ViewEventDao objViewEventDao = new ViewEventDao();
		List<Event> list_event=objViewEventDao.AllEvents(admin_id,content);
		request.setAttribute("EVENT_LIST",list_event);
		// send to jsp page(view)
		RequestDispatcher dispatcher = request.getRequestDispatcher("/search.jsp");
		dispatcher.forward(request, response);
		
	}
	private void contributeEvent(HttpServletRequest request, HttpServletResponse response) throws SQLException, ServletException, IOException {
		HttpSession session=request.getSession(false);
		 String admin_id= (String) session.getAttribute("uid");
				// get event-details from dao
				ViewEventDao objViewEventDao = new ViewEventDao();
		List<Event_Details> list_event_details=objViewEventDao.EventInner(admin_id);
		request.setAttribute("EVENT_DETAILS",list_event_details);
		// send to jsp page(view)
		RequestDispatcher dispatcher = request.getRequestDispatcher("/emp-event-inner.jsp");
		dispatcher.forward(request, response);
		
	}
	private void updateEvent(HttpServletRequest request, HttpServletResponse response) throws Exception{
		String event_id=request.getParameter("event_id");
		String eventname=request.getParameter("eventname");
		String startdate=request.getParameter("startdate");
		String enddate=request.getParameter("enddate");
		String venue=request.getParameter("venue");
		String time=request.getParameter("time");
		String expectamount=request.getParameter("expectamount");
		Float expect_amount=(float) Float.parseFloat(expectamount);
		System.out.println(expect_amount);
		String coordinator_id=request.getParameter("coordinator_id");
		String empexpectamt=request.getParameter("emp_expect_amt");
		Float emp_expect_amount= Float.parseFloat(empexpectamt);
		System.out.println(emp_expect_amount);
		Event objEventBean = new Event(event_id,eventname,startdate,enddate,venue,time,expect_amount,coordinator_id,emp_expect_amount);
		ViewEventDao objViewEventDao = new ViewEventDao();
		objViewEventDao.Update(objEventBean);
		listEvents(request,response);
	}
	private void delete(HttpServletRequest request, HttpServletResponse response) throws Exception{
		ViewEventDao objViewEventDao = new ViewEventDao();

		String event_id=request.getParameter("event_id");
		String s=objViewEventDao.DeleteEvent(event_id);
		if(s.equals("success")){
		
			listEvents(request,response);
		}
		else
		/*	 out.print("<html><body>");  
        out.println("<script type=\"text/javascript\">");
        out.println("alert('Operation failed');");
         out.println("</script>");
       out.print("</body></html>");
        out.close(); */
        listEvents(request,response);
	}
	private void edit(HttpServletRequest request, HttpServletResponse response)throws Exception {
		String event_id=request.getParameter("event_id");
		ViewEventDao objViewEventDao = new ViewEventDao();
		Event objEventBean =objViewEventDao.EditEvent(event_id);
		request.setAttribute("EditEvent",objEventBean);
		RequestDispatcher dispatcher = request.getRequestDispatcher("/admin-edit.jsp");
		dispatcher.forward(request, response);
		/*List<Event> s=objViewEventDao.EditEvent(event_id);*/
		
	} 
	private void listEvents(HttpServletRequest request, HttpServletResponse response) 
			  throws Exception{
		HttpSession session=request.getSession(false);
		 String admin_id= (String) session.getAttribute("uid");
				// get event-details from dao
				ViewEventDao objViewEventDao = new ViewEventDao();
				List<Event> list_events=objViewEventDao.GetEvents(admin_id);
	
				request.setAttribute("AMAL_EVENT",list_events);
				List<Event_Details> list_event_details=objViewEventDao.EventInner(admin_id);
				request.setAttribute("EVENT_DETAILS",list_event_details);
				// send to jsp page(view)
				RequestDispatcher dispatcher = request.getRequestDispatcher("/admin-event-inner.jsp");
				dispatcher.forward(request, response);
				
			}
			


}
