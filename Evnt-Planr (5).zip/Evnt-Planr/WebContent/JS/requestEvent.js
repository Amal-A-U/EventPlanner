function validate(){
	if(document.register.eventname.value === ""){
		alert("Please Enter your Event Name");
		document.register.eventname.focus();
		return false;
	}
	/*
	
	 // regular expression to match required date format
    re = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;

    if(document.register.startdate.value != '') {
      if(regs = document.register.startdate.value.match(re)) {
        // day value between 1 and 31
        if(regs[1] < 1 || regs[1] > 31) {
          alert("Invalid value for day: " + regs[1]);
          document.register.startdate.focus();
          return false;
        }
        // month value between 1 and 12
        if(regs[2] < 1 || regs[2] > 12) {
          alert("Invalid value for month: " + regs[2]);
          document.register.startdate.focus();
          return false;
        }
        // year value between 1902 and 2018
        if(regs[3] < 1902 || regs[3] > (new Date()).getFullYear()) {
          alert("Invalid value for year: " + regs[3] + " - must be between 1902 and " + (new Date()).getFullYear());
          document.register.startdate.focus();
          return false;
        }
      } else {
        alert("Invalid date format: " + document.register.startdate.value);
        document.register.startdate.focus();
        return false;
      }
*/
	


	if(document.register.startdate.value === ""){
		alert("Please Enter Event Start Date");
		document.register.startdate.focus();
		return false;
	}

	
	if(document.register.enddate.value === ""){
		alert("Please Enter Event End Date");
		document.register.enddate.focus();
		return false;
	}
	if(document.register.venue.value === ""){
		alert("Please Enter Event Venue");
		document.register.venue.focus();
		return false;
	}
	if(document.register.time.value === ""){
		alert("Please enter Event Time");
		document.register.time.focus();
		return false;
		
	}

	if (document.register.expectamount.value === "") {
		alert("Please enter Expected Amount");
		document.register.expectamount.focus();
		return false;
	}
	var expectamount=document.getElementById('expectamount').value;
	// Convert user entered age to a number
	
	//check if age is a number or less than or greater than 100
	if (isNaN(expectamount) )
	{ 
	  alert("The expectamount must be a number ");
	  return false;
	}
	/*var expectamount=document.getElementById('expectamount').value;
	// Convert user entered age to a number
	expectamount = parseInt(expectamount, 10);
	//check if age is a number or less than or greater than 100
	if (isNaN(expectamount) || expectamount < 0 || expectamount > 1000000)
	{ 
	  alert("The amount must be a number");
	  return false;
	}*/
	
	return true;
}








/*
    function checkDate(){
        var idate = document.getElementById("startdate"),
            resultDiv = document.getElementById("datewarn"),
            dateReg = /(0[1-9]|[12][0-9]|3[01])[\/](0[1-9]|1[012])[\/]201[4-9]|20[2-9][0-9]/;

        if(!dateReg.test(idate.value)){
            resultDiv.innerHTML = "Invalid date!";
            resultDiv.style.color = "red";
            return;            
        } 

        if(isFutureDate(idate.value)){
            resultDiv.innerHTML = "Entered date is a future date";
            resultDiv.style.color = "red";
        } else {
            resultDiv.innerHTML = "It's a valid date";
            resultDiv.style.color = "green";
        }
    }
    */
    
    
    
   /* function isFutureDate(idate){
        var today = new Date().getTime(),
            idate = idate.split("/");

        idate = new Date(idate[2], idate[1] - 1, idate[0]).getTime();
        return (today - idate) < 0;
    }*/