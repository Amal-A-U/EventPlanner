package com.event.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.event.bean.Event;
import com.event.dao.AdminHomeDao;
import com.event.dao.ViewEventDao;

/**
 * Servlet implementation class AdminHomeServlet
 */
@WebServlet("/AdminHomeServlet")
public class AdminHomeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public AdminHomeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession(false);
		String id=(String)session.getAttribute("uid");
		response.setHeader("Cache-Control","no-cache"); 
		response.setHeader("Cache-Control","no-store"); 
		response.setDateHeader("Expires", 0); 
		response.setHeader("Pragma","no-cache");
		if (null == id) {
		          request.setAttribute("Error", "Session Expired....  Please login again to continue.");
		           request.getRequestDispatcher("/home.jsp").forward(request, response);
		}
	
		try{
			String action=request.getParameter("action");
			if(action==null){
				System.out.println(" Action = null");
				/*listEvents(request,response);*/
			}
			if (action.equals("accept") ){
				System.out.println("action = accept");
				accept_s(request,response);
			}
			if (action.equals("reject")){
				System.out.println("action = reject");
				reject_s(request,response);
			}

		}
		catch(Exception exc){
			throw new ServletException(exc);
		}
		

		
		
	}

	private void accept_s(HttpServletRequest request, HttpServletResponse response)throws Exception {
		
		
		AdminHomeDao objAdminHomeDao = new AdminHomeDao();
		PrintWriter out=response.getWriter(); 
		String event_id=request.getParameter("event_id");
		String s=objAdminHomeDao.AcceptEvent(event_id);
		if(s.equals("success")){
			 EventList objEventList =new EventList();

	          objEventList.listEvents(request, response);
		}
		else{
			 EventList objEventList =new EventList();

        objEventList.listEvents(request, response);
		}
		
	}
	

	private void reject_s(HttpServletRequest request, HttpServletResponse response) throws Exception{
		AdminHomeDao objAdminHomeDao = new AdminHomeDao();
		PrintWriter out=response.getWriter(); 
		String event_id=request.getParameter("event_id");
		String s=objAdminHomeDao.RejectEvent(event_id);
		if(s.equals("success")){
			
	          EventList objEventList =new EventList();

	          objEventList.listEvents(request, response);
		}
		else
		{
		
        EventList objEventList =new EventList();

        objEventList.listEvents(request,response);
		}
	}
	
	
	
	
	
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	
	
	
}
