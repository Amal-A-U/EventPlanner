package com.event.servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.event.bean.Event;
import com.event.dao.EmpHomeDao;


/**
 * Servlet implementation class EmployeeHistoryServlet
 */
@WebServlet("/EmployeeHistoryServlet")
public class EmployeeHistoryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmployeeHistoryServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession(false);
		String id=(String)session.getAttribute("uid");
		response.setHeader("Cache-Control","no-cache"); 
		response.setHeader("Cache-Control","no-store"); 
		response.setDateHeader("Expires", 0); 
		response.setHeader("Pragma","no-cache");
		if (null == id) {
		          request.setAttribute("Error", "Session Expired....  Please login again to continue.");
		           request.getRequestDispatcher("/home.jsp").forward(request, response);
		}
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			EmployeeHistory(request,response);
		} catch (Exception e) {


			e.printStackTrace();
		}
	}

	private void EmployeeHistory(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, SQLException {
		
		      HttpSession session=request.getSession(false);
	
		      String emp_id=(String) session.getAttribute("uid");
		
				// get event-details from dao
		EmpHomeDao objEmpHomeDao = new EmpHomeDao();
				List<Event> EventAccepted=objEmpHomeDao.EventAccepted(emp_id);
				List<Event> EventRejected=objEmpHomeDao.EventRejected(emp_id);
				request.setAttribute("EventAccepted",EventAccepted);
				request.setAttribute("EventRejected",EventRejected);
				RequestDispatcher dispatcher = request.getRequestDispatcher("/employee-history.jsp");
				dispatcher.forward(request, response);
		
	}
		
	}


