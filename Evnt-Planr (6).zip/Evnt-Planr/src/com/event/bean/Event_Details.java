package com.event.bean;

public class Event_Details {
	private String event_id;
	private String employee_id;
	private String emp_contribute_amt;
	private String employee_status;
	private Float emp_expect_amt;
	public String getEvent_id() {
		return event_id;
	}
	public void setEvent_id(String event_id) {
		this.event_id = event_id;
	}
	public String getEmployee_id() {
		return employee_id;
	}
	public void setEmployee_id(String employee_id) {
		this.employee_id = employee_id;
	}
	public String getEmp_contribute_amt() {
		return emp_contribute_amt;
	}
	public void setEmp_contribute_amt(String emp_contribute_amt) {
		this.emp_contribute_amt = emp_contribute_amt;
	}
	public String getEmployee_status() {
		return employee_status;
	}
	public void setEmployee_status(String employee_status) {
		this.employee_status = employee_status;
	}
	public Event_Details(String event_id, String employee_id, String emp_contribute_amt, String employee_status) {
		super();
		this.event_id = event_id;
		this.employee_id = employee_id;
		this.emp_contribute_amt = emp_contribute_amt;
		this.employee_status = employee_status;
	}

	@Override
	public String toString() {
		return "Event_Details [event_id=" + event_id + ", employee_id=" + employee_id + ", emp_contribute_amt="
				+ emp_contribute_amt + ", employee_status=" + employee_status + "]";
	}
	/**
	 * @return the emp_expect_amt
	 */
	public Float getEmp_expect_amt() {
		return emp_expect_amt;
	}
	/**
	 * @param emp_expect_amt the emp_expect_amt to set
	 */
	public void setEmp_expect_amt(Float emp_expect_amt) {
		this.emp_expect_amt = emp_expect_amt;
	}
	public Event_Details(String event_id, String employee_id,String employee_status, Float emp_expect_amt,String emp_contribute_amt ) {
		super();
		this.event_id = event_id;
		this.employee_id = employee_id;
		this.emp_contribute_amt = emp_contribute_amt;
		this.employee_status = employee_status;
		this.emp_expect_amt = emp_expect_amt;
	}


}
