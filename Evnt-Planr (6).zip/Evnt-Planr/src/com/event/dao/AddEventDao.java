package com.event.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;
import com.event.bean.Event;
import com.event.web.jdbc.ConnectionClass;

public class AddEventDao {
	private String s=null;
	Connection con=null;
	Statement stmt= null;
	ResultSet rs1 = null;
	
	int rs = 0;
@SuppressWarnings("null")
public String insertEvent(Event objAddEventBean) throws SQLException, AddressException, MessagingException {
	try {
	String eventname=objAddEventBean.getEvent_name();
	String startdate=objAddEventBean.getStart_date();
	String enddate=objAddEventBean.getEnd_date();
	String venue=objAddEventBean.getVenue();
	String eventtime=objAddEventBean.getEvent_time();
	Float expectamount=objAddEventBean.getExpected_amount();
	String admin_id=objAddEventBean.getAdmin_id();
	String coordinator_id=objAddEventBean.getCoordinator_id();
	
	con=ConnectionClass.getConnection();
	
	stmt=con.createStatement();

PreparedStatement ps=null;
PreparedStatement ps1=null;

	String status="approved";
	System.out.println("1");

	  String sql1="select count(employee_id) from amal_employee where dept_id in(select dept_id from amal_employee where employee_id=?) ";
		System.out.println("2");
		
		ps1=con.prepareStatement(sql1);
		 ps1.setString(1,admin_id);
	rs1=ps1.executeQuery();
	System.out.println("3");

	float emp_count = 0;
	while(rs1.next()){
		// retrieve data from result set row
		emp_count=rs1.getInt(1);
	}
	System.out.println(emp_count);
	Float emp_expect=(float) expectamount/emp_count;
		String sql="insert into AMAL_EVENT (EVENT_NAME,START_DATE,END_DATE,VENUE,EVENT_TIME,EXPECTED_AMOUNT,EVENT_STATUS,ADMIN_ID,COORDINATOR_ID,EMP_EXPECT_AMT) values(?,?,?,?,?,?,?,?,?,?)";
		 ps=con.prepareStatement(sql);
	     ps.setString(1,eventname);
	     ps.setString(2,startdate);
	     ps.setString(3,enddate);
	     ps.setString(4,venue);
	     ps.setString(5,eventtime);
	     ps.setFloat(6,expectamount);
	     ps.setString(7,status);
	     ps.setString(8,admin_id);
	     ps.setString(9,coordinator_id);
	     ps.setFloat(10,emp_expect);
	     rs=ps.executeUpdate();
	     System.out.println("a");
	     ResultSet rs2=null;
	     PreparedStatement ps2=null;
	     String status2="employee";
	
	     System.out.println("b");
	 	  String sql2="select email from amal_employee where dept_id in (select dept_id from amal_employee where employee_id=?) and status=? ";
	 	 List<String> list=new ArrayList<String>();
	 		ps2=con.prepareStatement(sql2);
	 		 ps2.setString(1,admin_id);
	 		 ps2.setString(2,status2);
	 	    rs2 = ps2.executeQuery();
	 	System.out.println("c");
	 	while(rs2.next()){
	 		System.out.println("d");
	 		list.add(rs2.getString("EMAIL"));
	 	}
	 	System.out.println("e");
	     String body="Hi\n \tEVENT NAME :"+eventname.toUpperCase()+"\n \tDATE:"+startdate+"\n\tVENUE:"+venue.toUpperCase()+"\n\tCO-ORDINATOR:"+coordinator_id+"\n\n\nALL ARE WELCOME!!\n\nThanks and regards\nAmal AU ";
	  
	     sendEmail(eventname,list,"extern_au.amal@allianz.com",body);
	     System.out.println("f");
		System.out.println("afterdao");
		if(rs==1)
			s="success";
		else
			s="fail";
		System.out.println(rs);
		
}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	return s;
	}
private void sendEmail(String eventname, List<String> tolist, String from, String body)  throws AddressException,
    MessagingException{
		  List<String> list1=new ArrayList<String>();
		  list1=tolist;
                        
                        // Recipient's email ID needs to be mentioned.
             // String to = "extern_jose.bismi@allianz.com";

              // Sender's email ID needs to be mentioned
            //  String from = "extern_jose.bismi@allianz.com";

              // Assuming you are sending email from localhost
              String host = "tmu-econ.mail.allianz";

              // Get system properties
              Properties properties = System.getProperties();

              // Setup mail server
              properties.setProperty("mail.smtp.host", host);

              // Get the default Session object.
              Session session = Session.getDefaultInstance(properties);

              try {

                 // Create a default MimeMessage object.
                 MimeMessage message = new MimeMessage(session);

                 // Set From: header field of the header.
                 message.setFrom(new InternetAddress(from));
                 for (String temp : list1) {
          
                 // Set To: header field of the header.
                 message.addRecipient(Message.RecipientType.TO, new InternetAddress(temp));

                 // Set Subject: header field
                 message.setSubject(eventname);

                 // Now set the actual message
                 //message.setText("This is actual message");#
                 message.setText(body);

                 // Send message
                 Transport.send(message);
                 System.out.println("Sent message successfully....");
               
                 }
              } catch (MessagingException mex) {
                 mex.printStackTrace();
              }

                        
        }

 

}
