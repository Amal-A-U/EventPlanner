package com.event.bean;

public class AddEventBean {
	private  String event_id;
	private  String event_name;
	private  String start_date;
	private  String end_date;
	private  String venue;
	private  String event_time;
	private  String expected_amount;
	private  String total_amount;
	private  String event_status;

	public AddEventBean(String event_id, String event_name, String start_date, String end_date, String venue,
			String event_time, String expected_amount, String total_amount, String event_status) {
		super();
		this.event_id = event_id;
		this.event_name = event_name;
		this.start_date = start_date;
		this.end_date = end_date;
		this.venue = venue;
		this.event_time = event_time;
		this.expected_amount = expected_amount;
		this.total_amount = total_amount;
		this.event_status = event_status;
	}
	
	public AddEventBean(String event_name, String start_date, String end_date, String venue, String event_time,
			String expected_amount, String total_amount, String event_status) {
		this.event_name = event_name;
		this.start_date = start_date;
		this.end_date = end_date;
		this.venue = venue;
		this.event_time = event_time;
		this.expected_amount = expected_amount;
		this.total_amount = total_amount;
		this.event_status = event_status;
	}

	public AddEventBean() {
	
	}

	/**
	 * @return the event_id
	 */
	public String getEvent_id() {
		return event_id;
	}
	/**
	 * @param event_id the event_id to set
	 */
	public void setEvent_id(String event_id) {
		this.event_id = event_id;
	}
	/**
	 * @return the event_name
	 */
	public String getEvent_name() {
		return event_name;
	}
	/**
	 * @param event_name the event_name to set
	 */
	public void setEvent_name(String event_name) {
		this.event_name = event_name;
	}
	/**
	 * @return the start_date
	 */
	public String getStart_date() {
		return start_date;
	}
	/**
	 * @param start_date the start_date to set
	 */
	public void setStart_date(String start_date) {
		this.start_date = start_date;
	}
	/**
	 * @return the end_date
	 */
	public String getEnd_date() {
		return end_date;
	}
	/**
	 * @param end_date the end_date to set
	 */
	public void setEnd_date(String end_date) {
		this.end_date = end_date;
	}
	/**
	 * @return the venue
	 */
	public String getVenue() {
		return venue;
	}
	/**
	 * @param venue the venue to set
	 */
	public void setVenue(String venue) {
		this.venue = venue;
	}

	/**
	 * @return the event_time
	 */
	public String getEvent_time() {
		return event_time;
	}
	/**
	 * @param event_time the event_time to set
	 */
	public void setEvent_time(String event_time) {
		this.event_time = event_time;
	}
	/**
	 * @return the expected_amount
	 */
	public String getExpected_amount() {
		return expected_amount;
	}
	/**
	 * @param expected_amount the expected_amount to set
	 */
	public void setExpected_amount(String expected_amount) {
		this.expected_amount = expected_amount;
	}
	/**
	 * @return the total_amount
	 */
	public String getTotal_amount() {
		return total_amount;
	}
	/**
	 * @param total_amount the total_amount to set
	 */
	public void setTotal_amount(String total_amount) {
		this.total_amount = total_amount;
	}
	/**
	 * @return the event_status
	 */
	public String getEvent_status() {
		return event_status;
	}
	/**
	 * @param event_status the event_status to set
	 */
	public void setEvent_status(String event_status) {
		this.event_status = event_status;
	}

	@Override
	public String toString() {
		return "AddEventBean [event_id=" + event_id + ", event_name=" + event_name + ", start_date=" + start_date
				+ ", end_date=" + end_date + ", venue=" + venue + ", event_time=" + event_time + ", expected_amount="
				+ expected_amount + ", total_amount=" + total_amount + ", event_status=" + event_status + "]";
	}
	
	
	
}
