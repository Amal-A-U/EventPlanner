package com.event.servlet;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.event.bean.Emp_RegBean;
import com.event.dao.Emp_Registerdao;

/**
 * Servlet implementation class Emp_Register
 */
@WebServlet("/Emp_Register")
public class Emp_Register extends HttpServlet {
	private static final long serialVersionUID = 1L;
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Emp_RegBean objEmp_RegBean=new Emp_RegBean();
		objEmp_RegBean.setFirstName(request.getParameter("firstName"));
		objEmp_RegBean.setLastName(request.getParameter("lastName"));
		objEmp_RegBean.setEid(request.getParameter("eid"));
		objEmp_RegBean.setGender(request.getParameter("gender"));
		objEmp_RegBean.setAge(request.getParameter("age"));
		objEmp_RegBean.setEmail(request.getParameter("email"));
		objEmp_RegBean.setPhone(request.getParameter("phone"));
		objEmp_RegBean.setDept(request.getParameter("dept"));
		objEmp_RegBean.setPassword(request.getParameter("password"));
	
		
		Emp_Registerdao objEmp_Registerdao=new Emp_Registerdao();
		String str=objEmp_Registerdao.insertEmpDetails(objEmp_RegBean);
		if(str.equals("fail")){
			// Step 0: Add data
			String[] msg = {"Registration failed please Register again !"};
			request.setAttribute("msg_list", msg);
						
			// Step 1: get request dispatcher
			RequestDispatcher dispatcher = 
			request.getRequestDispatcher("/register.jsp");
							
			// Step 2: forward the request to JSP
			dispatcher.forward(request, response);
		}
		else{
			// Step 0: Add data
			String[] msg = {"Registration successful please login to continue !"};
			request.setAttribute("msg_list", msg);
			
			// Step 1: get request dispatcher
			RequestDispatcher dispatcher = request.getRequestDispatcher("/login.jsp");
			// Step 2: forward the request to JSP
			dispatcher.forward(request, response);
		}


	}


}
