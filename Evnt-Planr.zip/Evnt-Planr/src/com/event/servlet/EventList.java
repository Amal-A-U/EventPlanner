package com.event.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.event.bean.Employee;
import com.event.bean.Event;
import com.event.dao.ViewEventDao;

/**
 * Servlet implementation class EventList
 */
@WebServlet("/EventList")
public class EventList extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			listEvents(request,response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
/*		if(action==null){
			listEvents(request,response);
		}
		
		else if(action=='reject'{
			System.out.println("action1");
			
		
		
			
		}*/
		
	}



	void listEvents(HttpServletRequest request, HttpServletResponse response) 
			  throws Exception{
		HttpSession session=request.getSession(false);
		String id=(String)session.getAttribute("uid");
		response.setHeader("Cache-Control","no-cache"); 
		response.setHeader("Cache-Control","no-store"); 
		response.setDateHeader("Expires", 0); 
		response.setHeader("Pragma","no-cache");
		if (null == id) {
		          request.setAttribute("Error", "Session Expired....  Please login again to continue.");
		           request.getRequestDispatcher("/home.jsp").forward(request, response);
		}
	
		Employee objEmp = new Employee();
		HttpSession session1=request.getSession(false);
	
		String admin_id=(String) session1.getAttribute("uid");
		objEmp.setEid(admin_id);
				// get event-details from dao
				ViewEventDao objViewEventDao = new ViewEventDao();
				List<Event> Event_Request=objViewEventDao.EventRequest(objEmp);
				List<Event> Event_Reject=objViewEventDao.EventReject(objEmp);
		/*	for(AddEventBean list :list_events){
					
					System.out.println("value"+ list.getEvent_name());
				}*/
				// add event-details to the request
				request.setAttribute("Event_Request",Event_Request);
				request.setAttribute("Event_Reject",Event_Reject);
				
				// send to jsp page(view)
				RequestDispatcher dispatcher = request.getRequestDispatcher("/admin-home.jsp");
				dispatcher.forward(request, response);
				
			}
			
}
