package com.event.servlet;

import java.io.IOException;
import java.sql.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.event.bean.Login_FormBean;
import com.event.dao.LoginFormDao;

/**
 * Servlet implementation class Login_Form
 */
@WebServlet("/Login_Form")
public class Login_Form extends HttpServlet {
	public String s=null;
	private static final long serialVersionUID = 1L;
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Login_FormBean objLogin_FormBean= new Login_FormBean();
		objLogin_FormBean.setUsername(request.getParameter("employee-id"));
		objLogin_FormBean.setPassword(request.getParameter("password"));
		LoginFormDao objLoginFormDao= new LoginFormDao();
		try {
			 s = objLoginFormDao.CheckCredentials(objLogin_FormBean);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(s.equals("admin")){
			// Step 1: get request dispatcher
						RequestDispatcher dispatcher = 
						request.getRequestDispatcher("/admin-home.jsp");
										
						// Step 2: forward the request to JSP
						dispatcher.forward(request, response);
		}
		else if(s.equals("employee")){
			// Step 1: get request dispatcher
			RequestDispatcher dispatcher = 
			request.getRequestDispatcher("/employee-home.jsp");
							
			// Step 2: forward the request to JSP
			dispatcher.forward(request, response);
			
		}
		else{
			String[] msg = {"Invalid User Name or Password  please try again !"};
			request.setAttribute("msg", msg);
			RequestDispatcher dispatcher =request.getRequestDispatcher("/login.jsp");
			dispatcher.forward(request, response);
		}
		
	}

}
