package com.event.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.event.bean.Event;
import com.event.dao.ViewEventDao;

/**
 * Servlet implementation class ViewEvent
 */
@WebServlet("/ViewEvent")
public class ViewEvent extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//list the students in mvc fashion
		try{
		listEvents(request,response);
		}
		catch(Exception exc){
			throw new ServletException(exc);
		}
		

		
		
	}
	private void listEvents(HttpServletRequest request, HttpServletResponse response) 
			  throws Exception{
				// get event-details from dao
				ViewEventDao objViewEventDao = new ViewEventDao();
				List<Event> list_events=objViewEventDao.GetEvents();
		/*	for(AddEventBean list :list_events){
					
					System.out.println("value"+ list.getEvent_name());
				}*/
				// add event-details to the request
				request.setAttribute("AMAL_EVENT",list_events);
				
				// send to jsp page(view)
				RequestDispatcher dispatcher = request.getRequestDispatcher("/admin-event-inner.jsp");
				dispatcher.forward(request, response);
				
			}
			


}
