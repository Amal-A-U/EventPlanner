package com.event.dao;

import java.sql.*;
import com.event.bean.AddEventBean;
import com.event.web.jdbc.ConnectionClass;
public class AddEventDao {
	private String s=null;
	Connection con=null;
	Statement stmt= null;
	ResultSet rs = null;
public String insertEvent(AddEventBean objAddEventBean) throws SQLException {
		
	String eventname=objAddEventBean.getEvent_name();
	String startdate=objAddEventBean.getStart_date();
	String enddate=objAddEventBean.getEnd_date();
	String venue=objAddEventBean.getVenue();
	String eventtime=objAddEventBean.getEvent_time();
	String expectamount=objAddEventBean.getExpected_amount();
		con=ConnectionClass.getConnection();
		try {
			stmt=con.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		PreparedStatement ps=null;
		System.out.println("b4 dao");
		String sql="insert into AMAL_EVENT (EVENT_NAME,START_DATE,END_DATE,VENUE,EVENT_TIME,EXPECTED_AMOUNT) values(?,?,?,?,?,?)";
		 ps=con.prepareStatement(sql);
	     ps.setString(1,eventname);
	     ps.setString(2,startdate);
	     ps.setString(3,enddate);
	     ps.setString(4,venue);
	     ps.setString(5,eventtime);
	     ps.setString(6,expectamount);
			rs=ps.executeQuery();
		
		System.out.println("afterdao");
		if(rs.next())
			s="success";
		else
			s="fail";
		return s;
	}

}
