package com.event.dao;

import java.sql.*;
import com.event.bean.Event;
import com.event.web.jdbc.ConnectionClass;
public class AddEventDao {
	private String s=null;
	Connection con=null;
	Statement stmt= null;
	int rs = 0;
public String insertEvent(Event objAddEventBean) throws SQLException {
	try {
	String eventname=objAddEventBean.getEvent_name();
	String startdate=objAddEventBean.getStart_date();
	String enddate=objAddEventBean.getEnd_date();
	String venue=objAddEventBean.getVenue();
	String eventtime=objAddEventBean.getEvent_time();
	String expectamount=objAddEventBean.getExpected_amount();
	String admin_id=objAddEventBean.getAdmin_id();
	String coordinator_id=objAddEventBean.getCoordinator_id();
	
	String status="approved";
		con=ConnectionClass.getConnection();
		
			stmt=con.createStatement();
	
		PreparedStatement ps=null;
		System.out.println("b4 dao");
		String sql="insert into AMAL_EVENT (EVENT_NAME,START_DATE,END_DATE,VENUE,EVENT_TIME,EXPECTED_AMOUNT,EVENT_STATUS,ADMIN_ID,COORDINATOR_ID) values(?,?,?,?,?,?,?,?,?)";
		 ps=con.prepareStatement(sql);
	     ps.setString(1,eventname);
	     ps.setString(2,startdate);
	     ps.setString(3,enddate);
	     ps.setString(4,venue);
	     ps.setString(5,eventtime);
	     ps.setString(6,expectamount);
	     ps.setString(7,status);
	     ps.setString(8,admin_id);
	     ps.setString(9,coordinator_id);
	     rs=ps.executeUpdate();
		
		System.out.println("afterdao");
		if(rs==1)
			s="success";
		else
			s="fail";
		
}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	return s;
	}

}
