package com.event.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.*;

import com.event.bean.Event;
import com.event.web.jdbc.ConnectionClass;

public class ViewEventDao {

	public List<Event> GetEvents() throws Exception{
		List<Event> list_AddEventBean = new ArrayList<>();
		Connection con=null;
		Statement stmt= null;
		ResultSet rs = null;
		
		try{
			//get a connection
			con=ConnectionClass.getConnection();
			//create sql statement
			String sql="select * from AMAL_EVENT";
			/*where EVENT_STATUS='approved'*/
			stmt= con.createStatement();
			//execute query
			rs=stmt.executeQuery(sql);
			//process result set
			while(rs.next()){
				// retrieve data from result set row
				String eventId=rs.getString("EVENT_ID");
				String eventName=rs.getString("EVENT_NAME");
				String sdate=rs.getString("START_DATE");
				String edate=rs.getString("END_DATE");
				String e_venue=rs.getString("VENUE");
				String e_time=rs.getString("EVENT_TIME");
				Float e_exp_amount=rs.getFloat("EXPECTED_AMOUNT");
				Float e_actual_amt=rs.getFloat("TOTAL_AMOUNT");
				String e_expect_amt=rs.getString("EVENT_STATUS");
				String admin_id=rs.getString("ADMIN_ID");
				String coordinator_id=rs.getString("COORDINATOR_ID");
				Float emp_expect_amt=rs.getFloat("EMP_EXPECT_AMT");
				//create a new student object
				Event tempEvent = new Event(eventId,eventName,sdate,edate,e_venue,e_time,e_exp_amount,e_actual_amt,e_expect_amt,admin_id,coordinator_id,emp_expect_amt);
				list_AddEventBean.add(tempEvent);
				
			}
		/*	for(AddEventBean temp:list_AddEventBean){
				System.out.println("Name"+temp.getEvent_name());
			}*/
			
			return list_AddEventBean;
		}
		finally{
			//close jdbc objects
			close(con,stmt,rs);
		}
		
	}
	
	
	private void close(Connection con, Statement stmt, ResultSet rs) {
		try{
			if(rs!=null){
				rs.close();
			}
			if(stmt!=null){
				stmt.close();
			}
			if(con!=null){
				con.close();
			}
			
		}
		catch(Exception exc){
			exc.printStackTrace();
		}
	}


}
