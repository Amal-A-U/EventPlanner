package com.event.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;



import com.event.web.jdbc.ConnectionClass;

public class AdminHomeDao {
	
	public String AcceptEvent(String event_id) throws Exception{
		Connection con=null;
		Statement stmt= null;
		int rs = 0;
		PreparedStatement ps=null;
		String status="approved";
		String s=null;
		try{
			con=ConnectionClass.getConnection();
			String sql="update amal_event set event_status=? where event_id=?";
			stmt= con.createStatement();
		
			ps=con.prepareStatement(sql);
			 ps.setString(1,status);
			 ps.setString(2,event_id);
	    	rs=ps.executeUpdate();
		
			//process result set
			if(rs==1)
				s="success";
				else
					s="fail";
	
			return s;
		}
		finally{
			//close jdbc objects
			stmt.close();
			con.close();
		}
		
	}
	
	public String RejectEvent(String event_id) throws Exception{
		Connection con=null;
		Statement stmt= null;
		int rs = 0;
		PreparedStatement ps=null;
		String status="rejected";
		String s=null;
		try{
			con=ConnectionClass.getConnection();
			String sql="update amal_event set event_status=? where event_id=?";
			stmt= con.createStatement();
		
			ps=con.prepareStatement(sql);
			 ps.setString(1,status);
			 ps.setString(2,event_id);
	    	rs=ps.executeUpdate();
		
			//process result set
			if(rs==1)
				s="success";
				else
					s="fail";
	
			return s;
		}
		finally{
			//close jdbc objects
			stmt.close();
			con.close();
		}
		
	}


	
	

}
