package com.event.dao;

import java.sql.*;
import com.event.bean.Login_FormBean;
import com.event.web.jdbc.ConnectionClass;

public class LoginFormDao {
	Connection con=null;
	Statement stmt= null;
	ResultSet rs1 = null;
	ResultSet rs2 = null;
	ResultSet rs = null;
	String sql = null;
	
	public String CheckCredentials(Login_FormBean objLogin_FormBean) throws SQLException {
		String username=objLogin_FormBean.getUsername();
		String password=objLogin_FormBean.getPassword();
		String status="admin";
		String status1="employee";
		con=ConnectionClass.getConnection();
			stmt=con.createStatement();
			PreparedStatement ps=null;
			PreparedStatement ps1=null;
			
	     String sql1="select employee_id,password from amal_employee where employee_id=? and password=? and status=?";
	     ps=con.prepareStatement(sql1);
	     ps.setString(1,username);
	     ps.setString(2,password);
	     ps.setString(3,status);
	      rs1 = ps.executeQuery();
	    
	
		 sql1="select employee_id,password from amal_employee where employee_id=? and password=? and status=?";

		
		 ps1=con.prepareStatement(sql1);
	     ps1.setString(1,username);
	     ps1.setString(2,password);
	     ps1.setString(3,status1);
	     rs2 = ps1.executeQuery();
	     
			if(rs1.next()){
				String uname=rs1.getString(1);
				String paswd=rs1.getString(2);
				System.out.println(uname);
				System.out.println(paswd);
				if(uname.equals(username) && paswd.equals(password)){
					
				return "admin";
				}
			}
			else if(rs2.next()){
				String uname=rs2.getString(1);
				String paswd=rs2.getString(2);
				if(uname.equals(username) && paswd.equals(password)){
					
				return "employee";
				}
			}
			return "not registered";
	}

	
}
